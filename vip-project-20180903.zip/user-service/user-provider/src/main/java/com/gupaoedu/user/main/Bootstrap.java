package com.gupaoedu.user.main;

import com.alibaba.dubbo.container.Main;

/**
 * 腾讯课堂搜索 咕泡学院
 * 加群获取视频：608583947
 * 风骚的Michael 老师
 */
public class Bootstrap {

    public static void main(String[] args) {
        Main.main(args);
    }
}
