package com.gupaoedu.user.constants;

/**
 * 腾讯课堂搜索 咕泡学院
 * 加群获取视频：608583947
 * 风骚的Michael 老师
 */
public class Constants {

    public final static int NORMAL_USER_STATUS=1;
    public final static int FORZEN_USER_STATUS=2;
}
